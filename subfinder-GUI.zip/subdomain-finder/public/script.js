// Function to find subdomains and live domains (manual page)
async function findSubdomains() {
    const domain = document.getElementById('domain').value;
    const res = await fetch('/manual-subdomain-finder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ domain })
    });
    const data = await res.json();
    
    if (data.subdomains) {
        document.getElementById('subdomains').innerHTML = `
            <h2>Subdomains</h2>
            <ul>
                ${data.subdomains.map(subdomain => `<li>${subdomain}</li>`).join('')}
            </ul>
        `;
    }
    if (data.liveDomains) {
        document.getElementById('liveDomains').innerHTML = `
            <h2>Live Domains</h2>
            <ul>
                ${data.liveDomains.map(domain => `<li>${domain}</li>`).join('')}
            </ul>
        `;
    }
}

// Function to find live domains (automated page)
async function findLiveDomains() {
    const url = document.getElementById('url').value;
    const res = await fetch('/automated-live-domain-finder', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ domain: url })
    });
    const data = await res.json();
    
    if (data.liveDomains) {
        document.getElementById('liveDomains').innerHTML = `
            <h2>Live Domains</h2>
            <ul>
                ${data.liveDomains.map(domain => `<li>${domain}</li>`).join('')}
            </ul>
        `;
    }
}
